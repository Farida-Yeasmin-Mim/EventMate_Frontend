import {React, useEffect} from 'react';
import axios from 'axios';

function PostRequest(props) {

    useEffect(() => {
        console.log("ok");
    });
    // console.log("props");

    return (
        <div>          
        </div>
    );
}

export default PostRequest;